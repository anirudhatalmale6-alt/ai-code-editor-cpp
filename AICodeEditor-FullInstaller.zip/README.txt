=============================================
   AI CODE EDITOR - OFFLINE INSTALLER CD
=============================================

This CD contains everything you need to install
AI Code Editor on Windows 10 or Windows 11.


WHAT'S INCLUDED:
=============================================
- AI Code Editor (the main program)
- Install and Uninstall scripts
- Instructions for setting up AI features


INSTALLATION:
=============================================
1. Double-click INSTALL.bat
2. Follow the on-screen instructions
3. A shortcut will appear on your Desktop


FOR AI FEATURES (Chat & Suggestions):
=============================================
You need to install two additional programs:

1. PYTHON (required to run the editor)
   - Download from: https://www.python.org/downloads/
   - During install, CHECK "Add Python to PATH"

2. OLLAMA (required for AI features)
   - Download from: https://ollama.ai
   - After installing, open Command Prompt and run:
     ollama pull phi

   Note: "phi" is a small AI model that works on
   computers with 8GB RAM or less.


UNINSTALLING:
=============================================
Option 1: Use Start Menu > AI Code Editor > Uninstall
Option 2: Run UNINSTALL.bat from the install folder
          (Usually: C:\Users\YourName\AICodeEditor)


RUNNING THE EDITOR:
=============================================
- Double-click "AI Code Editor" on your Desktop
- Or find it in the Start Menu


FEATURES:
=============================================
- C/C++ code editor with syntax highlighting
- AI chat assistant for coding help
- Code suggestions and improvements
- Compile and run your code
- Dark theme (Windows 10/11 style)


KEYBOARD SHORTCUTS:
=============================================
Ctrl+N     New file
Ctrl+O     Open file
Ctrl+S     Save file
Ctrl+B     Compile
Ctrl+R     Run
F5         Build & Run


TROUBLESHOOTING:
=============================================
Q: "Python not found" error
A: Install Python and make sure you checked
   "Add Python to PATH" during installation.

Q: AI chat not responding
A: Make sure Ollama is installed and running.
   Open Command Prompt and run: ollama pull phi

Q: Compilation error "g++ not found"
A: You need a C++ compiler. Install MinGW-w64
   from: https://www.mingw-w64.org/


SYSTEM REQUIREMENTS:
=============================================
- Windows 10 or Windows 11 (32-bit or 64-bit)
- 4GB RAM minimum (8GB recommended for AI)
- 2GB free disk space
- Python 3.8 or higher
- Ollama (for AI features)


=============================================
       Thank you for using AI Code Editor!
=============================================
