#!/usr/bin/env python3
"""
AI Code Editor - A simple AI-powered C/C++ code editor
Works on Windows 10 (32-bit) and Windows 11 (64-bit)
Uses local Ollama for AI features
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
import subprocess
import threading
import json
import urllib.request
import urllib.error
import os
import re

class SyntaxHighlighter:
    """Simple C/C++ syntax highlighter"""

    KEYWORDS = [
        'auto', 'break', 'case', 'catch', 'class', 'const', 'continue',
        'default', 'delete', 'do', 'else', 'enum', 'explicit', 'extern',
        'false', 'for', 'friend', 'goto', 'if', 'inline', 'mutable',
        'namespace', 'new', 'nullptr', 'operator', 'private', 'protected',
        'public', 'return', 'sizeof', 'static', 'struct', 'switch',
        'template', 'this', 'throw', 'true', 'try', 'typedef', 'typename',
        'union', 'using', 'virtual', 'volatile', 'while', 'override', 'final'
    ]

    TYPES = [
        'bool', 'char', 'double', 'float', 'int', 'long', 'short',
        'signed', 'unsigned', 'void', 'wchar_t', 'string', 'vector',
        'map', 'set', 'list', 'FILE', 'size_t'
    ]

    def __init__(self, text_widget):
        self.text = text_widget
        self.text.tag_configure('keyword', foreground='#569cd6')
        self.text.tag_configure('type', foreground='#4ec9b0')
        self.text.tag_configure('string', foreground='#ce9178')
        self.text.tag_configure('comment', foreground='#6a9955')
        self.text.tag_configure('number', foreground='#b5cea8')
        self.text.tag_configure('preprocessor', foreground='#c586c0')
        self.text.tag_configure('function', foreground='#dcdcaa')

    def highlight(self, event=None):
        # Remove all tags
        for tag in ['keyword', 'type', 'string', 'comment', 'number', 'preprocessor', 'function']:
            self.text.tag_remove(tag, '1.0', 'end')

        content = self.text.get('1.0', 'end')

        # Highlight preprocessor directives
        for match in re.finditer(r'^\s*#.*$', content, re.MULTILINE):
            self._apply_tag('preprocessor', match)

        # Highlight keywords
        for keyword in self.KEYWORDS:
            for match in re.finditer(rf'\b{keyword}\b', content):
                self._apply_tag('keyword', match)

        # Highlight types
        for type_name in self.TYPES:
            for match in re.finditer(rf'\b{type_name}\b', content):
                self._apply_tag('type', match)

        # Highlight strings
        for match in re.finditer(r'"(?:[^"\\]|\\.)*"', content):
            self._apply_tag('string', match)

        # Highlight single-line comments
        for match in re.finditer(r'//.*$', content, re.MULTILINE):
            self._apply_tag('comment', match)

        # Highlight multi-line comments
        for match in re.finditer(r'/\*.*?\*/', content, re.DOTALL):
            self._apply_tag('comment', match)

        # Highlight numbers
        for match in re.finditer(r'\b\d+\.?\d*[fFlLuU]*\b', content):
            self._apply_tag('number', match)

        # Highlight function calls
        for match in re.finditer(r'\b([a-zA-Z_][a-zA-Z0-9_]*)\s*\(', content):
            start = f"1.0+{match.start(1)}c"
            end = f"1.0+{match.end(1)}c"
            self.text.tag_add('function', start, end)

    def _apply_tag(self, tag, match):
        start = f"1.0+{match.start()}c"
        end = f"1.0+{match.end()}c"
        self.text.tag_add(tag, start, end)


class AIService:
    """Handles communication with local Ollama AI"""

    # Models sorted by size (smallest first) - for low RAM systems
    AVAILABLE_MODELS = ["phi", "tinyllama", "gemma:2b", "llama2", "codellama", "mistral"]

    def __init__(self, endpoint="http://localhost:11434/api/generate", model="phi"):
        self.endpoint = endpoint
        self.model = model
        self.conversation_history = ""

    def set_model(self, model):
        """Change the AI model"""
        self.model = model

    def get_installed_models(self, callback=None):
        """Get list of installed Ollama models"""
        def _request():
            try:
                req = urllib.request.Request("http://localhost:11434/api/tags")
                with urllib.request.urlopen(req, timeout=5) as response:
                    result = json.loads(response.read().decode('utf-8'))
                    models = [m['name'].split(':')[0] for m in result.get('models', [])]
                    if callback:
                        callback(models if models else ["phi"], None)
            except:
                if callback:
                    callback(["phi"], "Could not fetch models")

        thread = threading.Thread(target=_request, daemon=True)
        thread.start()

    def send_message(self, message, code_context="", callback=None):
        """Send message to AI asynchronously"""
        def _request():
            try:
                prompt = self._build_prompt(message, code_context)

                data = json.dumps({
                    "model": self.model,
                    "prompt": prompt,
                    "stream": False,
                    "options": {
                        "temperature": 0.7,
                        "num_predict": 1024
                    }
                }).encode('utf-8')

                req = urllib.request.Request(
                    self.endpoint,
                    data=data,
                    headers={'Content-Type': 'application/json'}
                )

                with urllib.request.urlopen(req, timeout=60) as response:
                    result = json.loads(response.read().decode('utf-8'))
                    ai_response = result.get('response', 'No response received')
                    self.conversation_history += f"User: {message}\nAssistant: {ai_response}\n"
                    if callback:
                        callback(ai_response, None)
            except urllib.error.URLError as e:
                error_msg = "Cannot connect to Ollama. Please make sure Ollama is running.\n\n"
                error_msg += "To start:\n1. Install from https://ollama.ai\n"
                error_msg += "2. Run: ollama pull codellama\n"
                error_msg += "3. Ollama runs automatically in background"
                if callback:
                    callback(None, error_msg)
            except Exception as e:
                if callback:
                    callback(None, str(e))

        thread = threading.Thread(target=_request, daemon=True)
        thread.start()

    def _build_prompt(self, message, code_context):
        prompt = """You are an expert C/C++ programming assistant. Help users write, debug, and improve their code.
Be concise and practical. Focus on C89 through C23 and C++11 through C++23.

"""
        if self.conversation_history:
            prompt += f"Previous conversation:\n{self.conversation_history[-1500:]}\n\n"

        if code_context:
            prompt += f"Current code:\n```cpp\n{code_context}\n```\n\n"

        prompt += f"User: {message}"
        return prompt

    def get_suggestions(self, code, callback=None):
        """Get code improvement suggestions"""
        prompt = f"""Analyze this C/C++ code and provide 3-5 specific suggestions.
Use these prefixes:
🐛 for bugs
⚡ for performance
📝 for style
✨ for best practices
🔒 for security

Code:
```cpp
{code}
```

One suggestion per line, be brief:"""

        self.send_message(prompt, callback=callback)


class CompilerService:
    """Handles code compilation and execution"""

    def __init__(self):
        self.compiler = "g++"
        self.output_path = None

    def set_compiler(self, compiler):
        self.compiler = compiler

    def compile(self, source_file, callback=None):
        """Compile source file asynchronously"""
        def _compile():
            try:
                base = os.path.splitext(source_file)[0]
                self.output_path = base + ('.exe' if os.name == 'nt' else '')

                if self.compiler == 'cl':
                    cmd = ['cl', '/EHsc', '/W4', f'/Fe:{self.output_path}', source_file]
                else:
                    cmd = [self.compiler, '-std=c++17', '-Wall', '-o', self.output_path, source_file]

                result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)

                output = result.stdout + result.stderr
                success = result.returncode == 0

                if callback:
                    callback(success, output if output else "Compilation successful!")
            except FileNotFoundError:
                if callback:
                    callback(False, f"Compiler '{self.compiler}' not found. Please install it or check PATH.")
            except subprocess.TimeoutExpired:
                if callback:
                    callback(False, "Compilation timed out.")
            except Exception as e:
                if callback:
                    callback(False, str(e))

        thread = threading.Thread(target=_compile, daemon=True)
        thread.start()

    def run(self, callback=None):
        """Run compiled executable"""
        def _run():
            try:
                if not self.output_path or not os.path.exists(self.output_path):
                    if callback:
                        callback("No executable found. Please compile first.")
                    return

                result = subprocess.run([self.output_path], capture_output=True, text=True, timeout=30)
                output = result.stdout
                if result.stderr:
                    output += "\n[stderr]:\n" + result.stderr
                output += f"\n\n[Exit code: {result.returncode}]"

                if callback:
                    callback(output)
            except subprocess.TimeoutExpired:
                if callback:
                    callback("Program execution timed out (30s limit).")
            except Exception as e:
                if callback:
                    callback(f"Error: {str(e)}")

        thread = threading.Thread(target=_run, daemon=True)
        thread.start()


class AICodeEditor:
    """Main application window"""

    def __init__(self):
        self.root = tk.Tk()
        self.root.title("AI Code Editor")
        self.root.geometry("1400x900")
        self.root.minsize(1000, 600)

        # Dark theme colors
        self.colors = {
            'bg': '#1e1e1e',
            'fg': '#d4d4d4',
            'accent': '#0078d7',
            'editor_bg': '#1e1e1e',
            'panel_bg': '#252526',
            'border': '#3d3d3d',
            'button': '#0e639c',
            'button_hover': '#1177bb',
            'success': '#4ec9b0',
            'error': '#f14c4c'
        }

        # Configure dark theme
        self.root.configure(bg=self.colors['bg'])

        # Style configuration
        style = ttk.Style()
        style.theme_use('clam')
        style.configure('Dark.TFrame', background=self.colors['bg'])
        style.configure('Dark.TLabel', background=self.colors['bg'], foreground=self.colors['fg'])
        style.configure('Dark.TButton', background=self.colors['button'], foreground='white')
        style.configure('Dark.TNotebook', background=self.colors['panel_bg'])
        style.configure('Dark.TNotebook.Tab', background=self.colors['panel_bg'], foreground=self.colors['fg'], padding=[10, 5])
        style.map('Dark.TNotebook.Tab', background=[('selected', self.colors['bg'])])

        # Services
        self.ai_service = AIService()
        self.compiler_service = CompilerService()

        # State
        self.current_file = None
        self.is_modified = False

        self._setup_ui()
        self._setup_menu()
        self._setup_bindings()

    def _setup_ui(self):
        # Main container
        main_frame = ttk.Frame(self.root, style='Dark.TFrame')
        main_frame.pack(fill=tk.BOTH, expand=True)

        # Toolbar
        toolbar = tk.Frame(main_frame, bg=self.colors['panel_bg'], height=40)
        toolbar.pack(fill=tk.X, padx=0, pady=0)
        toolbar.pack_propagate(False)

        # Toolbar buttons
        btn_style = {'bg': self.colors['button'], 'fg': 'white', 'relief': 'flat', 'padx': 10, 'pady': 5}

        tk.Button(toolbar, text="New", command=self.new_file, **btn_style).pack(side=tk.LEFT, padx=2, pady=5)
        tk.Button(toolbar, text="Open", command=self.open_file, **btn_style).pack(side=tk.LEFT, padx=2, pady=5)
        tk.Button(toolbar, text="Save", command=self.save_file, **btn_style).pack(side=tk.LEFT, padx=2, pady=5)

        ttk.Separator(toolbar, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=10, pady=5)

        # Compiler selector
        tk.Label(toolbar, text="Compiler:", bg=self.colors['panel_bg'], fg=self.colors['fg']).pack(side=tk.LEFT, padx=5)
        self.compiler_var = tk.StringVar(value="g++")
        compiler_combo = ttk.Combobox(toolbar, textvariable=self.compiler_var, values=["g++", "clang++", "cl"], width=10)
        compiler_combo.pack(side=tk.LEFT, padx=5)
        compiler_combo.bind('<<ComboboxSelected>>', lambda e: self.compiler_service.set_compiler(self.compiler_var.get()))

        ttk.Separator(toolbar, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=10, pady=5)

        # AI Model selector
        tk.Label(toolbar, text="AI Model:", bg=self.colors['panel_bg'], fg=self.colors['fg']).pack(side=tk.LEFT, padx=5)
        self.model_var = tk.StringVar(value="phi")
        self.model_combo = ttk.Combobox(toolbar, textvariable=self.model_var,
                                         values=["phi", "tinyllama", "gemma:2b", "llama2", "codellama", "mistral"], width=12)
        self.model_combo.pack(side=tk.LEFT, padx=5)
        self.model_combo.bind('<<ComboboxSelected>>', lambda e: self.ai_service.set_model(self.model_var.get()))

        ttk.Separator(toolbar, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=10, pady=5)

        tk.Button(toolbar, text="▶ Compile", command=self.compile_code, **btn_style).pack(side=tk.LEFT, padx=2, pady=5)
        tk.Button(toolbar, text="▶ Run", command=self.run_code, **btn_style).pack(side=tk.LEFT, padx=2, pady=5)
        tk.Button(toolbar, text="▶ Build & Run", command=self.build_and_run, bg='#107c10', fg='white', relief='flat', padx=10, pady=5).pack(side=tk.LEFT, padx=2, pady=5)

        # Paned window for editor and AI panel
        paned = tk.PanedWindow(main_frame, orient=tk.HORIZONTAL, bg=self.colors['border'], sashwidth=4)
        paned.pack(fill=tk.BOTH, expand=True, padx=0, pady=0)

        # Left side - Code Editor
        editor_frame = tk.Frame(paned, bg=self.colors['bg'])

        # Line numbers + editor
        editor_container = tk.Frame(editor_frame, bg=self.colors['bg'])
        editor_container.pack(fill=tk.BOTH, expand=True)

        self.line_numbers = tk.Text(editor_container, width=4, bg='#1e1e1e', fg='#858585',
                                     state='disabled', font=('Consolas', 11))
        self.line_numbers.pack(side=tk.LEFT, fill=tk.Y)

        self.editor = tk.Text(editor_container, bg=self.colors['editor_bg'], fg=self.colors['fg'],
                               insertbackground='white', font=('Consolas', 11),
                               wrap=tk.NONE, undo=True, tabs='4c')
        self.editor.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # Scrollbars
        editor_scroll_y = ttk.Scrollbar(editor_container, command=self._scroll_both)
        editor_scroll_y.pack(side=tk.RIGHT, fill=tk.Y)
        self.editor.config(yscrollcommand=editor_scroll_y.set)

        editor_scroll_x = ttk.Scrollbar(editor_frame, orient=tk.HORIZONTAL, command=self.editor.xview)
        editor_scroll_x.pack(fill=tk.X)
        self.editor.config(xscrollcommand=editor_scroll_x.set)

        # Syntax highlighter
        self.highlighter = SyntaxHighlighter(self.editor)

        paned.add(editor_frame, minsize=400)

        # Right side - AI Panel
        ai_frame = tk.Frame(paned, bg=self.colors['panel_bg'])

        # Notebook for tabs
        self.notebook = ttk.Notebook(ai_frame, style='Dark.TNotebook')
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        # Chat tab
        chat_frame = tk.Frame(self.notebook, bg=self.colors['panel_bg'])

        tk.Label(chat_frame, text="💬 AI Assistant", bg=self.colors['panel_bg'], fg=self.colors['accent'],
                 font=('Segoe UI', 12, 'bold')).pack(anchor=tk.W, padx=10, pady=5)

        self.chat_history = scrolledtext.ScrolledText(chat_frame, bg=self.colors['bg'], fg=self.colors['fg'],
                                                       font=('Segoe UI', 10), wrap=tk.WORD, state='disabled')
        self.chat_history.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)

        chat_input_frame = tk.Frame(chat_frame, bg=self.colors['panel_bg'])
        chat_input_frame.pack(fill=tk.X, padx=10, pady=5)

        self.chat_input = tk.Entry(chat_input_frame, bg=self.colors['bg'], fg=self.colors['fg'],
                                    insertbackground='white', font=('Segoe UI', 10))
        self.chat_input.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 5))
        self.chat_input.bind('<Return>', lambda e: self.send_chat())

        tk.Button(chat_input_frame, text="Send", command=self.send_chat,
                  bg=self.colors['button'], fg='white', relief='flat').pack(side=tk.RIGHT)

        self.notebook.add(chat_frame, text="💬 Chat")

        # Suggestions tab
        suggestions_frame = tk.Frame(self.notebook, bg=self.colors['panel_bg'])

        tk.Label(suggestions_frame, text="💡 Ideas & Suggestions", bg=self.colors['panel_bg'], fg=self.colors['accent'],
                 font=('Segoe UI', 12, 'bold')).pack(anchor=tk.W, padx=10, pady=5)

        self.suggestions_list = tk.Listbox(suggestions_frame, bg=self.colors['bg'], fg=self.colors['fg'],
                                            font=('Segoe UI', 10), selectbackground=self.colors['accent'])
        self.suggestions_list.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)

        tk.Button(suggestions_frame, text="🔍 Get Suggestions", command=self.get_suggestions,
                  bg=self.colors['button'], fg='white', relief='flat', padx=15, pady=5).pack(pady=10)

        self.notebook.add(suggestions_frame, text="💡 Ideas")

        # Output tab
        output_frame = tk.Frame(self.notebook, bg=self.colors['panel_bg'])

        tk.Label(output_frame, text="📋 Compiler Output", bg=self.colors['panel_bg'], fg=self.colors['accent'],
                 font=('Segoe UI', 12, 'bold')).pack(anchor=tk.W, padx=10, pady=5)

        self.output_text = scrolledtext.ScrolledText(output_frame, bg='#1a1a1a', fg=self.colors['fg'],
                                                      font=('Consolas', 10), wrap=tk.WORD)
        self.output_text.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)

        tk.Button(output_frame, text="Clear", command=lambda: self.output_text.delete('1.0', tk.END),
                  bg='#4d4d4d', fg='white', relief='flat').pack(pady=5)

        self.notebook.add(output_frame, text="📋 Output")

        paned.add(ai_frame, minsize=300)

        # Status bar
        self.status_bar = tk.Label(self.root, text="Ready", bg=self.colors['accent'], fg='white', anchor=tk.W, padx=10)
        self.status_bar.pack(fill=tk.X, side=tk.BOTTOM)

    def _scroll_both(self, *args):
        self.editor.yview(*args)
        self.line_numbers.yview(*args)

    def _setup_menu(self):
        menubar = tk.Menu(self.root)

        # File menu
        file_menu = tk.Menu(menubar, tearoff=0)
        file_menu.add_command(label="New", command=self.new_file, accelerator="Ctrl+N")
        file_menu.add_command(label="Open", command=self.open_file, accelerator="Ctrl+O")
        file_menu.add_command(label="Save", command=self.save_file, accelerator="Ctrl+S")
        file_menu.add_command(label="Save As", command=self.save_file_as)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.root.quit)
        menubar.add_cascade(label="File", menu=file_menu)

        # Build menu
        build_menu = tk.Menu(menubar, tearoff=0)
        build_menu.add_command(label="Compile", command=self.compile_code, accelerator="Ctrl+B")
        build_menu.add_command(label="Run", command=self.run_code, accelerator="Ctrl+R")
        build_menu.add_command(label="Build & Run", command=self.build_and_run, accelerator="F5")
        menubar.add_cascade(label="Build", menu=build_menu)

        # Help menu
        help_menu = tk.Menu(menubar, tearoff=0)
        help_menu.add_command(label="About", command=self.show_about)
        menubar.add_cascade(label="Help", menu=help_menu)

        self.root.config(menu=menubar)

    def _setup_bindings(self):
        self.root.bind('<Control-n>', lambda e: self.new_file())
        self.root.bind('<Control-o>', lambda e: self.open_file())
        self.root.bind('<Control-s>', lambda e: self.save_file())
        self.root.bind('<Control-b>', lambda e: self.compile_code())
        self.root.bind('<Control-r>', lambda e: self.run_code())
        self.root.bind('<F5>', lambda e: self.build_and_run())

        # Update line numbers and highlighting
        self.editor.bind('<KeyRelease>', self._on_editor_change)
        self.editor.bind('<MouseWheel>', lambda e: self._update_line_numbers())

        # Right-click context menus
        self._setup_context_menus()

    def _setup_context_menus(self):
        """Setup right-click context menus for copy/paste"""
        # Context menu for code editor
        self.editor_menu = tk.Menu(self.root, tearoff=0)
        self.editor_menu.add_command(label="Cut", command=lambda: self.editor.event_generate("<<Cut>>"), accelerator="Ctrl+X")
        self.editor_menu.add_command(label="Copy", command=lambda: self.editor.event_generate("<<Copy>>"), accelerator="Ctrl+C")
        self.editor_menu.add_command(label="Paste", command=lambda: self.editor.event_generate("<<Paste>>"), accelerator="Ctrl+V")
        self.editor_menu.add_separator()
        self.editor_menu.add_command(label="Select All", command=lambda: self.editor.tag_add("sel", "1.0", "end"), accelerator="Ctrl+A")
        self.editor.bind("<Button-3>", lambda e: self._show_context_menu(e, self.editor_menu))

        # Context menu for chat history
        self.chat_menu = tk.Menu(self.root, tearoff=0)
        self.chat_menu.add_command(label="Copy", command=lambda: self._copy_from_widget(self.chat_history), accelerator="Ctrl+C")
        self.chat_menu.add_command(label="Paste", command=lambda: self._paste_to_chat_input(), accelerator="Ctrl+V")
        self.chat_menu.add_command(label="Select All", command=lambda: self._select_all_readonly(self.chat_history), accelerator="Ctrl+A")
        self.chat_history.bind("<Button-3>", lambda e: self._show_context_menu(e, self.chat_menu))

        # Context menu for output text
        self.output_menu = tk.Menu(self.root, tearoff=0)
        self.output_menu.add_command(label="Copy", command=lambda: self._copy_from_widget(self.output_text), accelerator="Ctrl+C")
        self.output_menu.add_command(label="Select All", command=lambda: self._select_all_readonly(self.output_text), accelerator="Ctrl+A")
        self.output_text.bind("<Button-3>", lambda e: self._show_context_menu(e, self.output_menu))

        # Context menu for chat input
        self.chat_input_menu = tk.Menu(self.root, tearoff=0)
        self.chat_input_menu.add_command(label="Cut", command=lambda: self.chat_input.event_generate("<<Cut>>"), accelerator="Ctrl+X")
        self.chat_input_menu.add_command(label="Copy", command=lambda: self.chat_input.event_generate("<<Copy>>"), accelerator="Ctrl+C")
        self.chat_input_menu.add_command(label="Paste", command=lambda: self.chat_input.event_generate("<<Paste>>"), accelerator="Ctrl+V")
        self.chat_input_menu.add_separator()
        self.chat_input_menu.add_command(label="Select All", command=lambda: self.chat_input.select_range(0, tk.END), accelerator="Ctrl+A")
        self.chat_input.bind("<Button-3>", lambda e: self._show_context_menu(e, self.chat_input_menu))

        # Enable keyboard copy for readonly widgets
        self.chat_history.bind("<Control-c>", lambda e: self._copy_from_widget(self.chat_history))
        self.output_text.bind("<Control-c>", lambda e: self._copy_from_widget(self.output_text))

    def _show_context_menu(self, event, menu):
        """Show context menu at mouse position"""
        try:
            menu.tk_popup(event.x_root, event.y_root)
        finally:
            menu.grab_release()

    def _copy_from_widget(self, widget):
        """Copy selected text from a widget to clipboard"""
        try:
            widget.config(state='normal')
            if widget.tag_ranges("sel"):
                selected_text = widget.get("sel.first", "sel.last")
                self.root.clipboard_clear()
                self.root.clipboard_append(selected_text)
            widget.config(state='disabled')
        except tk.TclError:
            pass

    def _select_all_readonly(self, widget):
        """Select all text in a readonly widget"""
        widget.config(state='normal')
        widget.tag_add("sel", "1.0", "end")
        widget.config(state='disabled')

    def _paste_to_chat_input(self):
        """Paste clipboard content to chat input"""
        try:
            text = self.root.clipboard_get()
            self.chat_input.insert(tk.END, text)
            self.chat_input.focus_set()
        except tk.TclError:
            pass

    def _on_editor_change(self, event=None):
        self.is_modified = True
        self._update_title()
        self._update_line_numbers()
        self.highlighter.highlight()

    def _update_line_numbers(self):
        self.line_numbers.config(state='normal')
        self.line_numbers.delete('1.0', tk.END)

        line_count = int(self.editor.index('end-1c').split('.')[0])
        line_numbers_text = '\n'.join(str(i) for i in range(1, line_count + 1))
        self.line_numbers.insert('1.0', line_numbers_text)
        self.line_numbers.config(state='disabled')

    def _update_title(self):
        title = "AI Code Editor"
        if self.current_file:
            title = os.path.basename(self.current_file) + " - " + title
        if self.is_modified:
            title = "• " + title
        self.root.title(title)

    def new_file(self):
        if self.is_modified:
            if not messagebox.askyesno("Unsaved Changes", "Discard unsaved changes?"):
                return
        self.editor.delete('1.0', tk.END)
        self.current_file = None
        self.is_modified = False
        self._update_title()
        self._update_line_numbers()

    def open_file(self):
        file_path = filedialog.askopenfilename(
            filetypes=[("C/C++ files", "*.c *.cpp *.cc *.h *.hpp"), ("All files", "*.*")]
        )
        if file_path:
            with open(file_path, 'r', encoding='utf-8') as f:
                self.editor.delete('1.0', tk.END)
                self.editor.insert('1.0', f.read())
            self.current_file = file_path
            self.is_modified = False
            self._update_title()
            self._update_line_numbers()
            self.highlighter.highlight()
            self.status_bar.config(text=f"Opened: {file_path}")

    def save_file(self):
        if self.current_file:
            with open(self.current_file, 'w', encoding='utf-8') as f:
                f.write(self.editor.get('1.0', tk.END))
            self.is_modified = False
            self._update_title()
            self.status_bar.config(text=f"Saved: {self.current_file}")
        else:
            self.save_file_as()

    def save_file_as(self):
        file_path = filedialog.asksaveasfilename(
            defaultextension=".cpp",
            filetypes=[("C++ files", "*.cpp"), ("C files", "*.c"), ("Header files", "*.h"), ("All files", "*.*")]
        )
        if file_path:
            self.current_file = file_path
            self.save_file()

    def compile_code(self):
        if not self.current_file:
            self.save_file_as()
            if not self.current_file:
                return
        elif self.is_modified:
            self.save_file()

        self.status_bar.config(text="Compiling...")
        self.notebook.select(2)  # Switch to Output tab

        def on_compile(success, output):
            self.output_text.delete('1.0', tk.END)
            if success:
                self.output_text.insert(tk.END, "✓ Compilation successful!\n\n" + output)
                self.status_bar.config(text="Compilation successful")
            else:
                self.output_text.insert(tk.END, "✗ Compilation failed:\n\n" + output)
                self.status_bar.config(text="Compilation failed")

        self.compiler_service.compile(self.current_file, callback=lambda s, o: self.root.after(0, lambda: on_compile(s, o)))

    def run_code(self):
        self.status_bar.config(text="Running...")
        self.notebook.select(2)

        def on_run(output):
            self.output_text.insert(tk.END, "\n--- Program Output ---\n" + output)
            self.status_bar.config(text="Execution finished")

        self.compiler_service.run(callback=lambda o: self.root.after(0, lambda: on_run(o)))

    def build_and_run(self):
        if not self.current_file:
            self.save_file_as()
            if not self.current_file:
                return
        elif self.is_modified:
            self.save_file()

        self.status_bar.config(text="Building...")
        self.notebook.select(2)

        def on_compile(success, output):
            self.output_text.delete('1.0', tk.END)
            if success:
                self.output_text.insert(tk.END, "✓ Build successful!\n\n")
                self.run_code()
            else:
                self.output_text.insert(tk.END, "✗ Build failed:\n\n" + output)
                self.status_bar.config(text="Build failed")

        self.compiler_service.compile(self.current_file, callback=lambda s, o: self.root.after(0, lambda: on_compile(s, o)))

    def send_chat(self):
        message = self.chat_input.get().strip()
        if not message:
            return

        self.chat_input.delete(0, tk.END)
        code = self.editor.get('1.0', tk.END)

        # Add user message
        self._append_chat("You", message, is_user=True)
        self.status_bar.config(text="AI is thinking...")

        def on_response(response, error):
            if error:
                self._append_chat("Error", error, is_error=True)
            else:
                self._append_chat("AI", response, is_user=False)
            self.status_bar.config(text="Ready")

        self.ai_service.send_message(message, code, callback=lambda r, e: self.root.after(0, lambda: on_response(r, e)))

    def _append_chat(self, sender, message, is_user=False, is_error=False):
        self.chat_history.config(state='normal')

        if is_error:
            color = self.colors['error']
        elif is_user:
            color = self.colors['accent']
        else:
            color = self.colors['success']

        self.chat_history.insert(tk.END, f"\n[{sender}]\n", 'sender')
        self.chat_history.insert(tk.END, f"{message}\n")
        self.chat_history.tag_config('sender', foreground=color, font=('Segoe UI', 10, 'bold'))

        self.chat_history.see(tk.END)
        self.chat_history.config(state='disabled')

    def get_suggestions(self):
        code = self.editor.get('1.0', tk.END).strip()
        if not code:
            messagebox.showinfo("Info", "Write some code first to get suggestions.")
            return

        self.suggestions_list.delete(0, tk.END)
        self.suggestions_list.insert(tk.END, "🔄 Analyzing code...")
        self.status_bar.config(text="Getting suggestions...")

        def on_response(response, error):
            self.suggestions_list.delete(0, tk.END)
            if error:
                self.suggestions_list.insert(tk.END, f"❌ {error}")
            else:
                lines = response.strip().split('\n')
                for line in lines:
                    if line.strip():
                        self.suggestions_list.insert(tk.END, line.strip())
            self.status_bar.config(text="Ready")

        self.ai_service.get_suggestions(code, callback=lambda r, e: self.root.after(0, lambda: on_response(r, e)))

    def show_about(self):
        messagebox.showinfo("About AI Code Editor",
            "AI Code Editor v1.0\n\n"
            "An AI-powered C/C++ code editor with local AI integration.\n\n"
            "Features:\n"
            "• Syntax highlighting\n"
            "• AI chat assistant\n"
            "• Code suggestions\n"
            "• Compiler integration\n\n"
            "Requires Ollama for AI features:\nhttps://ollama.ai")

    def run(self):
        self._update_line_numbers()
        self.root.mainloop()


if __name__ == "__main__":
    app = AICodeEditor()
    app.run()
