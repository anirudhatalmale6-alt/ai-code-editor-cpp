======================================
AI CODE EDITOR - Python Version
======================================

This is a lightweight Python version of the AI Code Editor
that works on both 32-bit and 64-bit Windows.

REQUIREMENTS:
- Python 3.8 or higher (free download from python.org)
- Ollama (for AI features - free from ollama.ai)

======================================
OPTION 1: RUN DIRECTLY (Easiest)
======================================

1. Install Python from: https://www.python.org/downloads/
   - Check "Add Python to PATH" during installation!

2. Double-click: RUN_EDITOR.bat
   OR
   Open Command Prompt and run: python ai_code_editor.py

======================================
OPTION 2: BUILD STANDALONE EXE
======================================

1. Install Python (see above)

2. Double-click: BUILD_EXE.bat

3. Wait for it to finish building

4. Find your EXE at: dist\AICodeEditor.exe

5. Copy AICodeEditor.exe anywhere you want!

======================================
SETTING UP AI FEATURES
======================================

1. Download Ollama from: https://ollama.ai

2. Install it (just double-click the installer)

3. Open Command Prompt and run:
   ollama pull codellama

4. That's it! Ollama runs in the background automatically.

======================================
FEATURES
======================================

- Modern dark theme UI
- C/C++ syntax highlighting
- Line numbers
- AI Chat assistant (asks questions about your code)
- AI Suggestions (analyzes your code for improvements)
- Compile & Run your code
- Supports GCC, Clang, and MSVC compilers

======================================
KEYBOARD SHORTCUTS
======================================

Ctrl+N     New file
Ctrl+O     Open file
Ctrl+S     Save file
Ctrl+B     Compile
Ctrl+R     Run
F5         Build & Run

======================================
